import React from "react";
interface SVGIconProps {
  fillColor?: string;
  width?: number;
  height?: number;
  style?: React.CSSProperties;
}
function SearchIcon(props: SVGIconProps) {
  const { width = 16, height = 16, style = {} } = props;
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 17"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{
        ...style,
      }}
    >
      <path
        d="M11.6666 12.1007L14.6666 15.1007"
        stroke="#7A869A"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M13.3333 7.76741C13.3333 4.4537 10.647 1.76741 7.33325 1.76741C4.01954 1.76741 1.33325 4.4537 1.33325 7.76741C1.33325 11.0811 4.01954 13.7674 7.33325 13.7674C10.647 13.7674 13.3333 11.0811 13.3333 7.76741Z"
        stroke="#7A869A"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
    </svg>
  );
}
export default SearchIcon;
