import React from "react";
import { SVGIconProps } from "./SVGIconProps";
function UpFromBracket(props: SVGIconProps) {
    const { width = 24, height = 24, fillColor = "#0830BC",onClick } = props;
    return (
        <svg width={width}
            height={height} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"  onClick={onClick}>
            <path d="M8.5625 9H10.25C10.6562 9 11 9.34375 11 9.75V13.5H13V9.75C13 9.34375 13.3125 9 13.75 9H15.4062L12 5.5625L8.5625 9ZM12 4C12.3438 4 12.6875 4.15625 12.9375 4.40625L16.5625 8.03125C16.8438 8.3125 17 8.6875 17 9.0625C17 9.875 16.3438 10.5 15.5312 10.5H14.5V13.5C14.5 14.3438 13.8125 15 13 15H11C10.1562 15 9.5 14.3438 9.5 13.5V10.5H8.4375C7.625 10.5 7 9.875 7 9.0625C7 8.6875 7.125 8.3125 7.40625 8.03125L11.0312 4.40625C11.2812 4.15625 11.625 4 12 4ZM6.5 14.75V17.25C6.5 17.9688 7.03125 18.5 7.75 18.5H16.25C16.9375 18.5 17.5 17.9688 17.5 17.25V14.75C17.5 14.3438 17.8125 14 18.25 14C18.6562 14 19 14.3438 19 14.75V17.25C19 18.7812 17.75 20 16.25 20H7.75C6.21875 20 5 18.7812 5 17.25V14.75C5 14.3438 5.3125 14 5.75 14C6.15625 14 6.5 14.3438 6.5 14.75Z" fill={fillColor} />
        </svg>
    );
}
export default UpFromBracket;