import React from "react";
import { SVGIconProps } from "./SVGIconProps";
function ArrowLeft(props: SVGIconProps) {
  const { width = 18, height = 13, fillColor = "#7A869A",onClick } = props;
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 18 13"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      onClick={onClick}
    >
      <path
        d="M2 6.63648L17 6.63623"
        stroke={fillColor}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M6 1.63623L1.70711 5.92912C1.37377 6.26246 1.20711 6.42912 1.20711 6.63623C1.20711 6.84334 1.37377 7.01 1.70711 7.34334L6 11.6362"
        stroke={fillColor}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
}
export default ArrowLeft;
