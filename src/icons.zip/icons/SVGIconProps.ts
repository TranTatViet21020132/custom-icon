export interface SVGIconProps {
    fillColor?: string;
    width?: number;
    height?: number;
    onClick?: (event: any) => void;
}